package teamproject.comProject.Controller;

import java.util.ArrayList;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;

import teamproject.comProject.DTO.Free_Board;
import teamproject.comProject.DTO.Pager;
import teamproject.comProject.Service.Service_Board_Function;

public class Board_Controller {
	JSONObject jsonObject;
	JSONArray jsonArray;
	Free_Board free_Board = new Free_Board();
	String Output;
	String json;
	Service_Board_Function sbf = new Service_Board_Function();
	Pager pager = new Pager();
	
	public String InputJson (JSONObject jsonObject) {
		String command =  jsonObject.getString("Command");
		
		switch(command) {
			case "writeFb" :
				free_Board.setUser_Id(jsonObject.getString("user_Id"));
				free_Board.setFree_Btitle(jsonObject.getString("free_Btitle"));
				free_Board.setFree_Bcontent(jsonObject.getString("free_Bcontent"));
				
				Output = sbf.writeFb(free_Board);
				
				if(Output.equals("success")) {
					jsonObject.put("Command", "Board_Function");
					jsonObject.put("message", "게시글 입력 완료");
					jsonObject.put("step", "next");
					json = jsonObject.toString();
					
				} else if( Output.equals("fail")) {
					jsonObject.put("Command", "Board_Function");
					jsonObject.put("message", "게시글 입력 오류");
					jsonObject.put("step", "retry");
					json = jsonObject.toString();
					
				} else {
					jsonObject.put("Command", "Board_Function");
					jsonObject.put("message", "error");
					json = jsonObject.toString();
				}
				break;
				
			case "readFb" :
				ArrayList<Free_Board> list = new ArrayList<>();
				list = sbf.readFb("readFb");
				
				JSONObject sendRoot = new JSONObject();
				sendRoot.put("result", "product");
				JSONObject data = new JSONObject();
				JSONArray pl = new JSONArray();
				
				for( Free_Board F : list) {
					JSONObject limitJop = new JSONObject();
					limitJop.put("free_Bno", F.getFree_Bno());
					limitJop.put("free_Btitle", F.getFree_Btitle());
					limitJop.put("free_Bcontent", F.getFree_Bcontent());
					limitJop.put("free_Date", F.getFree_Date());
					limitJop.put("user_Id", F.getUser_Id());
					
					pl.put(limitJop);
				}
				data.put("freeBoardList", pl);
				sendRoot.put("data",data);
				json = sendRoot.toString();
				
				break;
				
			case "readFb2" : 
				free_Board.setFree_Bno(jsonObject.getString("selectFbNum"));
				Free_Board free_Board2 = sbf.selectFb(free_Board);
				
				JSONObject limitJop = new JSONObject();
				limitJop.put("free_Bno", free_Board2.getFree_Bno());
				limitJop.put("free_Btitle", free_Board2.getFree_Btitle());
				limitJop.put("free_Bcontent", free_Board2.getFree_Bcontent());
				limitJop.put("free_Date", free_Board2.getFree_Date());
				limitJop.put("user_Id", free_Board2.getUser_Id());
				json = limitJop.toString();
			break;
				
			
			
			
		}
		return json;
	}
	
	
	
	
	
	
}
