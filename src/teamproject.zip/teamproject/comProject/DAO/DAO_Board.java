package teamproject.comProject.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import teamproject.comProject.DTO.Free_Board;
import teamproject.comProject.DTO.Pager;
import teamproject.comProject.server.ConnectionProvider;

public class DAO_Board {
	String Output;
	int countRow;
	Pager pager = new Pager();
	
	public String Insert(Free_Board free_Board) {
		String sql = "insert into free_board (free_bno, free_btitle, free_bcontent, free_date, free_comment_num, users_User_Id) "
				+ " values (free_bno.nextval, ?, ?, sysdate, free_conum.nextval, ? ) ";
		Connection conn = ConnectionProvider.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			//입력됨.
			pstmt.setString(1, free_Board.getFree_Btitle());
			pstmt.setString(2, free_Board.getFree_Bcontent());
			pstmt.setString(3, free_Board.getUser_Id());
			pstmt.executeUpdate();
			pstmt.close();
			Output = "success";
				
		} catch (Exception e) {
			Output = "fail";
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return Output;	
	}
	public Free_Board ReadFb(Free_Board free_Board) {
		String sql = "select Free_Btitle, Free_Bcontent, Free_Date, users_user_id,  free_bno "
				+ "from free_board "
				+ "where free_bno = ? ";
		Free_Board free_Board2 = new Free_Board();
		Connection conn = ConnectionProvider.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, free_Board.getFree_Bno());
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				free_Board2.setFree_Btitle(rs.getString(1));
				free_Board2.setFree_Bcontent(rs.getString(2));
				free_Board2.setFree_Date(rs.getString(3));
				free_Board2.setUser_Id(rs.getString(4));
				free_Board2.setFree_Bno(rs.getString(5));
			}
			pstmt.close();
			rs.close();
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return free_Board2;
	}
	
	
	
	
	
	public ArrayList<Free_Board> ReadAll(String readFb) {
		
		ArrayList<Free_Board> list = new ArrayList<>();
		String sql = "select Free_Btitle, Free_Bcontent, Free_Date, users_user_id,  free_bno "
				+ "from free_board "
				+ "order by free_bno desc ";
		Connection conn = ConnectionProvider.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				Free_Board free_Board = new Free_Board();
				free_Board.setFree_Btitle(rs.getString(1));
				free_Board.setFree_Bcontent(rs.getString(2));
				free_Board.setFree_Date(rs.getString(3));
				free_Board.setUser_Id(rs.getString(4));
				free_Board.setFree_Bno(rs.getString(5));
				
				list.add(free_Board);
			}
			
			pstmt.close();
			rs.close();
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public int getTotalRow() {
		String sql = "select count (*) from free_board";
		Connection conn = ConnectionProvider.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			
			while (rs.next()) {
				countRow = rs.getInt("count");
			}
			pstmt.close();
			rs.close();
		} catch (Exception e) {
			e.getStackTrace();
		} finally {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return countRow;
	}
	
	
	
	
	
	
	
	
	
}
