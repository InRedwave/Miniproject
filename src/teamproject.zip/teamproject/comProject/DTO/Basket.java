package teamproject.comProject.DTO;

import lombok.Data;

@Data
public class Basket {
	private String user_Id;
	private int total_price;
}
