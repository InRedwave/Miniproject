package teamproject.comProject.DTO;


import lombok.Data;

@Data
public class Free_Board {
	 private String free_Bno;
	 private String free_Btitle;
	 private String free_Bcontent;
	 
	 private String free_Date;
	 private String user_Id;
	 private int free_Comment_Num;
}
