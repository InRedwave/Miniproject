package teamproject.comProject.DTO;

import java.util.Date;

import lombok.Data;

@Data

public class Free_Comment {
	 private String free_Conum;
	 private String free_Cocontent;
	 private Date free_Codate;
	 private String user_Id;
	 private String free_Bno;
}
