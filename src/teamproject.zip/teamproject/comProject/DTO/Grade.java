package teamproject.comProject.DTO;

import lombok.Data;

@Data
public class Grade {
	 private String grade_Name;
	 private int low_Purchase;
	 private int high_Purchase;
}
