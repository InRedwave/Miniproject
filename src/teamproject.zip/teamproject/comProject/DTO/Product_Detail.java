package teamproject.comProject.DTO;

import lombok.Data;

@Data
public class Product_Detail {
	private String detail_Id;
	private String detail_Color;
	private String detail_Capacity;
	private String product_Id;
	private int detail_Qnt;
}
