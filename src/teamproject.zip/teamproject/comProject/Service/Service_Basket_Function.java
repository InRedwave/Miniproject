package teamproject.comProject.Service;

import teamproject.comProject.DAO.DAO_Basket;
import teamproject.comProject.DTO.Basket;
import teamproject.comProject.DTO.Basket_Detail;

public class Service_Basket_Function {
	DAO_Basket Db = new DAO_Basket();
	String Output;
	
	public String Create_Basket(Basket basket ) {
		Db = new DAO_Basket();
		Output = Db.Create(basket);
		return Output;
	}
	
	
	
}
