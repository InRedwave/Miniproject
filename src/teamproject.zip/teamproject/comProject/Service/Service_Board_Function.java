package teamproject.comProject.Service;

import java.util.ArrayList;

import teamproject.comProject.DAO.DAO_Board;
import teamproject.comProject.DTO.Free_Board;
import teamproject.comProject.DTO.Pager;

public class Service_Board_Function {
	DAO_Board Db = new DAO_Board();
	Free_Board free_Board = new Free_Board();
	String Output;
	int totalRow;
	
	public int getTotalRow() {
		Db = new DAO_Board();
		totalRow = Db.getTotalRow();
		return totalRow;
	}
	
	
	public String writeFb(Free_Board free_Board) {
		Db = new DAO_Board();
		Output = Db.Insert(free_Board);
		return Output;
	}
	
	public ArrayList<Free_Board> readFb(String readFb) {
		ArrayList<Free_Board> list = new ArrayList<>();
		Db = new DAO_Board();
		list = Db.ReadAll(readFb);
		return list;
	}
	
	public Free_Board selectFb(Free_Board free_Board) {
		Db= new DAO_Board();
		Free_Board free_Board2 = new Free_Board();
		free_Board2 = Db.ReadFb(free_Board);
		return free_Board2;
	}
	
	
	
	
	
	
}
