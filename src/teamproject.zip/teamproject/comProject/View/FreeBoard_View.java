package teamproject.comProject.View;

import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONObject;

import teamproject.comProject.DTO.Free_Board;
import teamproject.comProject.DTO.Pager;
import teamproject.comProject.client.Board_Function;
import teamproject.comProject.client.Client;

public class FreeBoard_View {
	Scanner sc = new Scanner(System.in);
	String selectNumber;
	Board_Function boardFunction = new Board_Function();
	Client client;
	JSONObject jsonObject;
	JSONArray jsonArray;
	Free_Board free_Board= new Free_Board();
	Pager pager = new Pager();
	
	public FreeBoard_View(Client client) {
		this.client = client;
	}
	
	
	public void startFB() {
		System.out.println("[자유 게시판] | [1. 게시글 작성] | [2. 게시글 목록] ");
		
		System.out.println("------------------------------------------------------");       
		selectNumber = sc.nextLine();
		
		if(selectNumber.equals("1")) {
			System.out.println("[1. 게시글 작성] | ");
			boardFunction.writeFb(client);
			
		} else if(selectNumber.equals("2")) {
			readAll();
			
		}
	}
	
	
	public void readAll() {
		boardFunction.readFb(client);
		JSONObject root = new JSONObject(client.receive());
		JSONObject data = root.getJSONObject("data");
		JSONArray pl = data.getJSONArray("freeBoardList");
		System.out.println("[자유 게시판 게시글 목록]");
		System.out.println("--------------------------------------------------");
		System.out.printf("%-6s%-12s%-16s%-16s\n", "| 게시물 번호 |", "| 게시물 제목 | ", "| 작성자 | ", "| 작성 일자 |");
		for(int i = 0; i<pl.length(); i++) {
			JSONObject limitJop = pl.getJSONObject(i);
			free_Board.setFree_Bno(limitJop.getString("free_Bno"));
			free_Board.setFree_Btitle(limitJop.getString("free_Btitle"));
			free_Board.setFree_Bcontent(limitJop.getString("free_Bcontent"));
			free_Board.setFree_Date(limitJop.getString("free_Date"));
			free_Board.setUser_Id(limitJop.getString("user_Id"));
			System.out.printf("%-10s%-20s%-40s%-50s\n",free_Board.getFree_Bno(),
			free_Board.getFree_Btitle(),free_Board.getUser_Id(), free_Board.getFree_Date());
		}
		readFB();
	}
	
	
	public void readFB() {
		System.out.println("--------------------------------------------------");
		System.out.println("읽을 게시물 선택 : ");
		System.out.print("> : ");
		String selectFbNum =sc.nextLine();
		
		boardFunction.readFb(client, selectFbNum);
		JSONObject root1 = new JSONObject(client.receive());
		System.out.println("[자유 게시판 게시글 읽기]");
		System.out.println("--------------------------------------------------");
		System.out.println("   [게시물 제목]   | [게시물 작성자] | [게시물 번호]");
		System.out.println(root1.getString("free_Btitle") + " | " + root1.getString("user_Id") + " | " + root1.getString("free_Bno"));
		System.out.println("--------------------------------------------------");
		System.out.println("                [게시물 내용]                        ");
		System.out.println(root1.getString("free_Bcontent"));
		
		System.out.println("--------------------------------------------------");
		System.out.println("[1. 목록으로 돌아가기] ]");
		selectNumber = sc.nextLine();
		if(selectNumber.equals("1")) {
			readAll();
		}
	}
	
	
	
	
	
}
