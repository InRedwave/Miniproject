package teamproject.comProject.client;

import java.io.IOException;
import java.net.Socket;
import java.util.Date;
import java.util.Scanner;

import org.json.JSONObject;

import teamproject.comProject.DTO.Free_Board;
import teamproject.comProject.DTO.Pager;

public class Board_Function {
	Socket socket;
	Scanner sc = new Scanner(System.in);
	JSONObject JsonObject = new JSONObject();
	Free_Board fb = new Free_Board();
	String json;
	
	public void createFbTitle() {
		System.out.println("########[자유 게시판]########");
		System.out.println("[새 게시글]");
		while(true) {
			System.out.print("제목: ");  
			String valid = sc.nextLine();
			if(valid.length()<=10) {
				fb.setFree_Btitle(valid); 
				break;
			} else {
				System.out.println("글자수 10자 이하로 작성해주세요.");
				System.out.print("제목: ");  
			}
		}
	}
	
	public void createFbContent() {
		while(true) {
			System.out.print("내용: "); 
			String valid = sc.nextLine();
			if(valid.length()<=333) {
				fb.setFree_Bcontent(valid); 
				break;
			} else {
				System.out.println("글자수 333자 이하로 작성해주세요.");
				System.out.print("내용: "); 
			}
		}
	}
	
	public void createFbNickname() {
		while(true) {
			System.out.print("닉네임 : "); 
			String valid = sc.nextLine();
			if(valid.length()<=10) {
				fb.setUser_Id(valid); 
				break;
			} else {
				System.out.println("글자수 10자 이하로 작성해주세요.");
				System.out.print("닉네임 : "); 
			}
		}
	}
	
	
	
	public void writeFb(Client client) {
		try {
		createFbTitle();
		createFbContent();
		fb.setUser_Id(client.user.getUser_Id());
		JsonObject.put("Command", "writeFb");
		JsonObject.put("controller", "Board_Function");
		JsonObject.put("free_Btitle", fb.getFree_Btitle());
		JsonObject.put("free_Bcontent", fb.getFree_Bcontent());
		JsonObject.put("user_Id", fb.getUser_Id());
		
		String json = JsonObject.toString();
		client.send(json);
		System.out.println("전송완료");
		
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("게시글 작성 요청 오류");
		}
		
	}	
	
	public void readFb(Client client) {
		System.out.println("게시글 읽기");
		
		try {
		JsonObject.put("Command","readFb");
		JsonObject.put("controller", "Board_Function");
		
		String json = JsonObject.toString();
		client.send(json);
		System.out.println("전송완료");
		
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("게시글 읽기 요청 오류");
		}
		
	}
	
	public void readFb(Client client, String selectFbNum) {
		System.out.println("게시글 선택");
		try {
			JsonObject.put("Command","readFb2");
			JsonObject.put("controller", "Board_Function");
			JsonObject.put("selectFbNum", selectFbNum);
			String json = JsonObject.toString();
			client.send(json);
			System.out.println("전송완료");
			
			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("게시글 선택 요청 오류");
			}
	}
	
	
	
			               
			
			
		
	
}
