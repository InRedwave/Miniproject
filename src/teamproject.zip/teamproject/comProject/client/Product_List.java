package teamproject.comProject.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.JSONObject;

import teamproject.comProject.DTO.Page;
import teamproject.comProject.DTO.Product;
import teamproject.comProject.DTO.Product_Detail;

public class Product_List implements Paging {
	public Page page;
	public Client client;

	public Product_List(Client client) {
		this.client = client;
		JSONObject jsonObject_row = new JSONObject();
		jsonObject_row.put("Command", "getTotalRow");

		try {
			this.client.send(jsonObject_row.toString());

			String json_row = client.receive();

			JSONObject root_row = new JSONObject(json_row);

			page = new Page();
			page.setTotalRow(root_row.getInt("totalRow"));
			page.setCurrPage(1);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void getEntireList() throws IOException {
		Product[] product = null;
		try {

			setPageInfo(page, 1, 5);
			// 상품목록출력
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("Command", "ProductList");

			jsonObject.put("startRow", String.valueOf(page.getStartRow()));
			jsonObject.put("endRow", String.valueOf(page.getEndRow()));

			String json = jsonObject.toString();
			client.send(json);
			System.out.println("상품목록");
			System.out.println("--------------------------------------------------");
			System.out.printf("%-6s%-6s%-12s%-12s\n","번호","상품번호","상품명","가격");
			product = new Product[page.getEndRow() - page.getStartRow() + 1];
			for (int i = page.getStartRow(); i <= page.getEndRow(); i++) {

				String json2 = client.receive();
				JSONObject root = new JSONObject(json2);

				int j = i - page.getStartRow();
				product[j] = new Product();

				product[j].setProduct_Id(root.getString("2"));
				product[j].setProduct_Name(root.getString("3"));
				product[j].setProduct_Price(root.getInt("4"));

				System.out.println("--------------------------------------------------");
				System.out.printf("%-6s",(j+1) + " ");
				System.out.printf("%-8s%-12s%-12d \n", product[j].getProduct_Id(), product[j].getProduct_Name(),
						product[j].getProduct_Price());

				System.out.println("--------------------------------------------------");

			}

			printPaging(page);

		} catch (Exception e) {
			System.out.println("[클라이언트] 서버 연결 안됨");
			e.printStackTrace();
		}
		Scanner sc = new Scanner(System.in);
		String select = sc.nextLine();
		try {
			if (Integer.parseInt(select) <= page.getRowsPerPage()) {
				// System.out.println(product[Integer.parseInt(select)-1].getProduct_Id());
				product_detail(product[Integer.parseInt(select) - 1].getProduct_Id());
			}
		} catch (Exception e) {
			//e.printStackTrace();
			switch (select) {
			case "n":
				page.setCurrPage(page.getCurrPage() + 1);

				getEntireList();
				break;
			case "p":
				page.setCurrPage(page.getCurrPage() - 1);
				getEntireList();
				break;
			case "pp":
				page.setCurrPage(1);
				getEntireList();
				break;
			case "nn":
				page.setCurrPage(page.getTotalPage());
				getEntireList();
				break;

			}
		}

	}

	public void product_detail(String product_Id) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("Command", "ProductContent");

		jsonObject.put("Product_Id", product_Id);

		String json = jsonObject.toString();

		try {
			client.send(json);
			String receiveJson = client.receive();
			JSONObject root = new JSONObject(receiveJson);
			Product product = new Product();
			// 상품명, 가격, 설명, 그래픽카드, cpu, 메인보드,os,ram

			product.setProduct_Name(root.getString("Product_Name"));
			product.setProduct_Price(root.getInt("Product_Price"));
			product.setProduct_Content(root.getString("Product_Content"));
			product.setProduct_Graphic_Card(root.getString("Product_Graphic_Card"));
			product.setCPU(root.getString("CPU"));
			product.setMainboard(root.getString("Mainboard"));
			product.setOS(root.getString("OS"));
			product.setMemory(root.getString("Memory"));

			System.out.println("상품명 : " + product.getProduct_Name());
			System.out.println("가격 : " + product.getProduct_Price());
			System.out.println("설명 : " + product.getProduct_Content());
			System.out.println("그래픽 카드 :" + product.getProduct_Graphic_Card());
			System.out.println("cpu : " + product.getCPU());
			System.out.println("메인보드 : " + product.getMainboard());
			System.out.println("운영체제 : " + product.getOS());
			System.out.println("RAM : " + product.getMemory());
			// 옵션
			Scanner sc = new Scanner(System.in);
			System.out.println("1.장바구니에 담기 2.뒤로가기");
			System.out.print("입력) ");

			if (sc.nextLine().equals("1")) {
				jsonObject = new JSONObject();
				jsonObject.put("Command", "ProductOption1");

				jsonObject.put("Product_Id", product_Id);
				json = jsonObject.toString();
				client.send(json);
				System.out.println();
				System.out.println("옵션 선택");
				System.out.println("---------------------------------------------------");
				System.out.print("1. 색상 : ");
				do {
					receiveJson = client.receive();
					root = new JSONObject(receiveJson);
					Product_Detail pd = new Product_Detail();

					pd.setDetail_Color(root.getString("Detail_Color"));

					System.out.print("[" + pd.getDetail_Color() + "]");
				} while (root.getBoolean("isExist"));
				System.out.println();
				System.out.print("색상입력 : ");
				String color = sc.nextLine();
				jsonObject = new JSONObject();
				jsonObject.put("Command", "ProductOption2");

				jsonObject.put("Product_Id", product_Id);
				jsonObject.put("Color", color);

				json = jsonObject.toString();
				client.send(json);
				System.out.print("2. 용량 : ");
				do {
					receiveJson = client.receive();
					root = new JSONObject(receiveJson);
					Product_Detail pd = new Product_Detail();

					pd.setDetail_Capacity(root.getString("Detail_Capacity"));

					System.out.print("[" + pd.getDetail_Capacity() + "]");
				} while (root.getBoolean("isExist"));
				System.out.println();
				System.out.print("용량입력 : ");
				String capacity = sc.nextLine();
				System.out.println("장바구니에 추가");
			}else {
				getEntireList();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
}
